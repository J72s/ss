module.exports = {
    token: "MTE5NDMxNDAxNjYxMzQ2NjEyMg.GDJ44e.v-Mgm4ZfTqYyv5XFXoIsMcsVV_j-zyXKpzPiZw",
    prefix: "2",
};

/* remove .example from the name of this file */