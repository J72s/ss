const strings = require("../strings.json");
const utils = require("../utils");
const allowedUsers = require("../allowed.json").allowedUsers;

/** 
 * @description Stops the music and make the bot leave the channel
 * @param {Discord.Client} client the client that runs the commands
 * @param {Discord.Message} message the command's message
 * @param {Array<String>}args useless here  
 */
module.exports.run = async (client, message, args) => {
    try {
        const serverQueue = queue.get("queue");
        if (!serverQueue) {
            return message.channel.send(strings.nothingPlaying);
        }

        serverQueue.songs = [];

        client.channels.cache.get('1240050863007862815').send("Stopped playing music");

        if (serverQueue.connection) {
            serverQueue.connection._state.subscription.player.stop();
        } else {
            return message.channel.send(strings.errorStop);
        }

        return message.channel.send(strings.musicStopped);
    } catch (error) {
        // Log the error
        console.error("Error occurred while stopping music:", error);
        
        // Send the error to the specified text channel
        const errorChannelId = '1240780333826445372'; // Replace with your error channel ID
        const errorChannel = client.channels.cache.get(errorChannelId);
        if (errorChannel && errorChannel.type === 'text') {
            errorChannel.send("Error occurred while stopping music:", error);
        } else {
            console.error("Error channel not found or not a text channel.");
        }

        message.channel.send(strings.errorStopping);
    }
};

module.exports.names = {
    list: ["stop", "st","وقف"]
};
